﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class FormHoaDon : Form
    {
        public FormHoaDon()
        {
            InitializeComponent();
        }

        private void FormHoaDon_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qlquaythuocDataSet.Hoadon' table. You can move, or remove it, as needed.
            this.HoadonTableAdapter.Fill(this.qlquaythuocDataSet.Hoadon);

            this.reportViewer1.RefreshReport();
        }
    }
}
