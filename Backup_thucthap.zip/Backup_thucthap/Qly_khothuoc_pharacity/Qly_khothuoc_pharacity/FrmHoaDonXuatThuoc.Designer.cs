﻿
namespace Qly_khothuoc_pharacity
{
    partial class FrmHoaDonXuatThuoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_CH = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_lai = new System.Windows.Forms.Button();
            this.bt_xoa = new System.Windows.Forms.Button();
            this.bt_sua = new System.Windows.Forms.Button();
            this.bt_them = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtthanhtien = new System.Windows.Forms.TextBox();
            this.cb_thuoc = new System.Windows.Forms.ComboBox();
            this.cb_dongia = new System.Windows.Forms.ComboBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
           // this.qlquaythuocDataSet1 = new Qly_khothuoc_pharacity.qlquaythuocDataSet1();
            this.hoadonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            //this.hoadonTableAdapter = new Qly_khothuoc_pharacity.qlquaythuocDataSet1TableAdapters.HoadonTableAdapter();
            this.label6 = new System.Windows.Forms.Label();
            this.txtma = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
          //  ((System.ComponentModel.ISupportInitialize)(this.qlquaythuocDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hoadonBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(25, 106);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(577, 311);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(271, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Phiếu Xuất Kho";
            // 
            // cb_CH
            // 
            this.cb_CH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_CH.FormattingEnabled = true;
            this.cb_CH.Location = new System.Drawing.Point(732, 132);
            this.cb_CH.Name = "cb_CH";
            this.cb_CH.Size = new System.Drawing.Size(156, 33);
            this.cb_CH.TabIndex = 2;
            this.cb_CH.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(608, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Chọn cơ sở";
            // 
            // bt_lai
            // 
            this.bt_lai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_lai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_lai.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_lai.Location = new System.Drawing.Point(742, 500);
            this.bt_lai.Name = "bt_lai";
            this.bt_lai.Size = new System.Drawing.Size(131, 40);
            this.bt_lai.TabIndex = 246;
            this.bt_lai.Text = "Thoát";
            this.bt_lai.UseVisualStyleBackColor = false;
            this.bt_lai.Click += new System.EventHandler(this.bt_lai_Click);
            // 
            // bt_xoa
            // 
            this.bt_xoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_xoa.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_xoa.Location = new System.Drawing.Point(571, 500);
            this.bt_xoa.Name = "bt_xoa";
            this.bt_xoa.Size = new System.Drawing.Size(131, 40);
            this.bt_xoa.TabIndex = 245;
            this.bt_xoa.Text = "Xóa";
            this.bt_xoa.UseVisualStyleBackColor = false;
            this.bt_xoa.Click += new System.EventHandler(this.bt_xoa_Click);
            // 
            // bt_sua
            // 
            this.bt_sua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_sua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_sua.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_sua.Location = new System.Drawing.Point(405, 500);
            this.bt_sua.Name = "bt_sua";
            this.bt_sua.Size = new System.Drawing.Size(131, 40);
            this.bt_sua.TabIndex = 244;
            this.bt_sua.Text = "Sửa";
            this.bt_sua.UseVisualStyleBackColor = false;
            this.bt_sua.Click += new System.EventHandler(this.bt_sua_Click);
            // 
            // bt_them
            // 
            this.bt_them.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_them.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_them.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_them.Location = new System.Drawing.Point(249, 500);
            this.bt_them.Name = "bt_them";
            this.bt_them.Size = new System.Drawing.Size(131, 40);
            this.bt_them.TabIndex = 243;
            this.bt_them.Text = "Thêm";
            this.bt_them.UseVisualStyleBackColor = false;
            this.bt_them.Click += new System.EventHandler(this.bt_them_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(711, 546);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 57);
            this.button1.TabIndex = 247;
            this.button1.Text = "IN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(608, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 20);
            this.label7.TabIndex = 264;
            this.label7.Text = "Thành tiền";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(608, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 263;
            this.label5.Text = "Đơn giá";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(608, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 262;
            this.label4.Text = "Số lượng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(608, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 20);
            this.label3.TabIndex = 261;
            this.label3.Text = "Tên thuốc";
            // 
            // txtthanhtien
            // 
            this.txtthanhtien.AccessibleName = "thanhTienTb";
            this.txtthanhtien.Enabled = false;
            this.txtthanhtien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtthanhtien.Location = new System.Drawing.Point(732, 350);
            this.txtthanhtien.Name = "txtthanhtien";
            this.txtthanhtien.Size = new System.Drawing.Size(243, 27);
            this.txtthanhtien.TabIndex = 267;
            // 
            // cb_thuoc
            // 
            this.cb_thuoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_thuoc.FormattingEnabled = true;
            this.cb_thuoc.Location = new System.Drawing.Point(732, 184);
            this.cb_thuoc.Name = "cb_thuoc";
            this.cb_thuoc.Size = new System.Drawing.Size(156, 33);
            this.cb_thuoc.TabIndex = 268;
            this.cb_thuoc.SelectedIndexChanged += new System.EventHandler(this.cb_thuoc_SelectedIndexChanged);
            // 
            // cb_dongia
            // 
            this.cb_dongia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_dongia.FormattingEnabled = true;
            this.cb_dongia.Location = new System.Drawing.Point(732, 297);
            this.cb_dongia.Name = "cb_dongia";
            this.cb_dongia.Size = new System.Drawing.Size(156, 33);
            this.cb_dongia.TabIndex = 270;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.AccessibleName = "soLuonTb";
            this.txtSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong.Location = new System.Drawing.Point(732, 243);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(156, 27);
            this.txtSoLuong.TabIndex = 271;
            this.txtSoLuong.TextChanged += new System.EventHandler(this.Hienthitien);
            // 
            // qlquaythuocDataSet1
            // 
         //   this.qlquaythuocDataSet1.DataSetName = "qlquaythuocDataSet1";
         //   this.qlquaythuocDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hoadonBindingSource
            // 
            this.hoadonBindingSource.DataMember = "Hoadon";
          // this.hoadonBindingSource.DataSource = this.qlquaythuocDataSet1;
            // 
            // hoadonTableAdapter
            // 
          //  this.hoadonTableAdapter.ClearBeforeFill = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(608, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 20);
            this.label6.TabIndex = 272;
            this.label6.Text = "Mã hóa đơn";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtma
            // 
            this.txtma.AccessibleName = "";
            this.txtma.Location = new System.Drawing.Point(732, 92);
            this.txtma.Name = "txtma";
            this.txtma.Size = new System.Drawing.Size(156, 22);
            this.txtma.TabIndex = 273;
            // 
            // FrmHoaDonXuatThuoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 671);
            this.Controls.Add(this.txtma);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.cb_dongia);
            this.Controls.Add(this.cb_thuoc);
            this.Controls.Add(this.txtthanhtien);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bt_lai);
            this.Controls.Add(this.bt_xoa);
            this.Controls.Add(this.bt_sua);
            this.Controls.Add(this.bt_them);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_CH);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FrmHoaDonXuatThuoc";
            this.Text = "FrmHoaDonXuatThuoc";
            this.Load += new System.EventHandler(this.FrmHoaDonXuatThuoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
          //  ((System.ComponentModel.ISupportInitialize)(this.qlquaythuocDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hoadonBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_CH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_lai;
        private System.Windows.Forms.Button bt_xoa;
        private System.Windows.Forms.Button bt_sua;
        private System.Windows.Forms.Button bt_them;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtthanhtien;
        private System.Windows.Forms.ComboBox cb_thuoc;
        private System.Windows.Forms.ComboBox cb_dongia;
        private System.Windows.Forms.TextBox txtSoLuong;
       // private qlquaythuocDataSet1 qlquaythuocDataSet1;
        private System.Windows.Forms.BindingSource hoadonBindingSource;
       // private qlquaythuocDataSet1TableAdapters.HoadonTableAdapter hoadonTableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtma;
    }
}