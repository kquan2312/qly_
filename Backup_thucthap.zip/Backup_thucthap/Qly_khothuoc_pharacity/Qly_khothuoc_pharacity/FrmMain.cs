﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class FrmMain : Form
    {
        ketnoi con = new ketnoi();
        string username = "", password = "", fullname = "", email = "", mod = "", state = "";
        public FrmMain()
        {
            InitializeComponent();
        }
        public FrmMain(string username, string password, string fullname, string email, string mod, string state)
        {
            InitializeComponent();
            this.username = username;
            this.password = password;
            this.fullname = fullname;
            this.email = email;
            this.mod = mod;
            this.state = state;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lb_email_Click(object sender, EventArgs e)
        {

        }

        private void lb_tenTK_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lb_quyen_Click(object sender, EventArgs e)
        {

        }

        private void tenTK_Click(object sender, EventArgs e)
        {

        }

        private void lb_ten_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pic_Click(object sender, EventArgs e)
        {

        }

        private void bảnQuyềnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void hướngDẫnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tácGiảToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void trợGiúpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void paintToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cuahangToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           
        }

        private void thuocToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void báoCáoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void QLCửahangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_Qly_CuaHang frm = new Form_Qly_CuaHang();
            frm.Show();
        }

        private void QLThuốcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormQlyThuoc frm = new FormQlyThuoc();
            frm.Show();
        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát chứ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                this.Show();
            }
            else
            {
                this.Hide();
                FormDangnhap frm = new FormDangnhap();
                frm.Show();
            }
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDoiMK frm = new FormDoiMK();
            frm.ShowDialog();
        }

        private void quảnLýTàiKhoảnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form_QLTK frm = new Form_QLTK();
            frm.ShowDialog();
        }

        private void quảnLýTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tiệnÍchToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            lb_tenTK.Text = username;
            lb_ten.Text = fullname;
            lb_email.Text = email;
            lb_quyen.Text = mod;
            if (mod == "user")
            {
                quảnLýTàiKhoảnToolStripMenuItem1.Visible = false;
            }
            else if (mod == "admin")
            {
                quảnLýTàiKhoảnToolStripMenuItem1.Visible = true;
            }
        }
    }
}
