﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class FrmHoaDonXuatThuoc : Form
    {
        ketnoi con = new ketnoi();
        public FrmHoaDonXuatThuoc()
        {

            InitializeComponent();

        }

        private void txtnhacc_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmHoaDonXuatThuoc_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qlquaythuocDataSet1.Hoadon' table. You can move, or remove it, as needed.
            //this.hoadonTableAdapter.Fill(this.qlquaythuocDataSet1.Hoadon);
            
            BindingSource bindingSource = new BindingSource();
            DataTable dt2 = con.setdata("select * from cuahang");
            cb_CH.DataSource = dt2;
            cb_CH.DisplayMember = "macuahang";
            cb_CH.ValueMember = "macuahang";
            txtthanhtien.ReadOnly = true;

            DataTable dt3 = con.setdata("select * from thuoc");
            bindingSource.DataSource = dt3;
            cb_thuoc.DataSource = bindingSource.DataSource;
            cb_thuoc.DisplayMember = "tenthuoc";
            cb_thuoc.ValueMember = "tenthuoc";

        //    cb_sl.DataSource = bindingSource.DataSource;
      //      cb_sl.DisplayMember = "soluong";
        //    cb_sl.ValueMember = "soluong";

            cb_dongia.DataSource = bindingSource.DataSource;
            cb_dongia.DisplayMember = "dongia";
            cb_dongia.ValueMember = "dongia";


            //cb_thuoc.SelectedIndexChanged += new EventHandler(cb_thuoc_SelectedIndexChanged);

            // Gọi hàm để cập nhật giá trị cho các ComboBox khác dựa trên giá trị mặc định của cb_thuoc
            //UpdateOtherComboBoxValues();

            DataTable dt1 = con.setdata("select * from Hoadon");
            dataGridView1.DataSource = dt1;
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //comboBox1.Enabled = false;

        }
        private void Hienthitien(object sender, EventArgs e)
        {
            //double so1, so2, tich;
            //so1 = Convert.ToDouble(cb_sl.Text);
            //so2 = Convert.ToDouble(cb_dongia.Text);
            //tich = so1 * so2;
            //txtthanhtien.Text = tich.ToString();
            var text = txtSoLuong.Text;
            int number;
            if (!int.TryParse(text, out number))//ktra nhap so
            {
                this.txtthanhtien.Text = "So luong khong hop le";
                return;
            }
            int donGia = int.Parse(cb_dongia.Text);
            this.txtthanhtien.Text = (number * donGia) + "";

        }

        private void UpdateOtherComboBoxValues()
        {
            // Lấy giá trị được chọn trong ComboBox "cb_thuoc"
           // string selectedThuoc = cb_thuoc.SelectedValue.ToString();

            // Truy vấn cơ sở dữ liệu để lấy thông tin liên quan đến thuốc được chọn
           // DataTable dtThuocInfo = con.setdata("select * from thuoc where tenthuoc = '" + selectedThuoc + "'");

            // Kiểm tra xem đã có dữ liệu hay không
          //if (dtThuocInfo.Rows.Count > 0)
         //{
                // Cập nhật giá trị cho các ComboBox khác
            //    cb_sl.SelectedValue = dtThuocInfo.Rows[0]["soluong"].ToString();
            //    cb_dongia.SelectedValue = dtThuocInfo.Rows[0]["dongia"].ToString();
              //  Hienthitien();
           // }
            
        }

        private void cb_thuoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateOtherComboBoxValues();
        }

        private void cb_sl_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void bt_them_Click(object sender, EventArgs e)
        {
            if (txtma.Text=="")
            {
                MessageBox.Show("Nhập mã hóa đơn");
                txtma.Focus();
            }
            else {
                if (con.getdata("insert into Hoadon values (N'" + txtma.Text + "',N'" + cb_CH.Text + "',N'" + cb_thuoc.Text + "',N'" + txtSoLuong.Text + "',N'" + cb_dongia.Text + "',N'" + txtthanhtien.Text + "')") == true)
                {
                    MessageBox.Show("Đã thêm thành công ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FrmHoaDonXuatThuoc_Load(sender, e);
                }
                else
                {
                    MessageBox.Show(" thêm không thành công ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void bt_sua_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("update Hoadon set tenthuoc=N'" + cb_thuoc.Text + "', soluong = N'" + txtSoLuong.Text + "', dongia = N'"
            //    + cb_dongia.Text + "',thanhtien=N'" + txtthanhtien.Text + "' where macuahang=N '" + comboBox1.Text + "'");
            //if (con.getdata("update Hoadon set tenthuoc=N'" + cb_thuoc.Text + "',soluong=N'" + txtSoLuong.Text + "', dongia=N'"
            //      + cb_dongia.Text + "',thanhtien=N'" + txtthanhtien.Text + "' where macuahang=N'" + comboBox1.Text + "'") == true)
                if (con.getdata("update Hoadon set mahoadon=N'" + txtma.Text + "',macuahang=N'" + cb_CH.Text + "',soluong=N'" + txtSoLuong.Text + "', dongia=N'"
                       + cb_dongia.Text + "',thanhtien=N'" + txtthanhtien.Text + "' where tenthuoc=N'" + cb_thuoc.Text + "'") == true)
                {

                MessageBox.Show("Sửa thành công");
                FrmHoaDonXuatThuoc_Load(sender, e);


            }
            else
            {
                MessageBox.Show("Sửa không thành công");
                FrmHoaDonXuatThuoc_Load(sender, e);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0 && dataGridView1.CurrentRow != null)
            //if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index >= 0 && dataGridView1.CurrentRow.Index < dataGridView1.Rows.Count)
            {
                txtma.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                cb_CH.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                cb_thuoc.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtSoLuong.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                cb_dongia.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                txtthanhtien.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
              //  txtnhacc.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                //cbbmacuahang.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            }
        }

        private void bt_xoa_Click(object sender, EventArgs e)
        {
            if (con.getdata("delete FROM Hoadon where tenthuoc = N'" + cb_thuoc.Text + "'") == true)
            {

                MessageBox.Show("Xóa dữ liệu thành công");

                FrmHoaDonXuatThuoc_Load(sender, e);
            }
           else
                MessageBox.Show("Không thể xóa dữ liệu");
        
                
    }

        private void button1_Click(object sender, EventArgs e)
        {
            FormHoaDon f = new FormHoaDon();
            f.ShowDialog();
        }

        private void bt_lai_Click(object sender, EventArgs e)
        {
            this.Hide(); 
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
