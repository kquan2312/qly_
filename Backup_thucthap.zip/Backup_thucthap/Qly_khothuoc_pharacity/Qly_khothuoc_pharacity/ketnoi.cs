﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Qly_khothuoc_pharacity
{
    class ketnoi
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=qlquaythuoc;Integrated Security=True");
        //biến con sqlconection để kêt nối đến CSDL
        public void open() //mở kết nối
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        public void close()  //đóng kết nối
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

        }
        public Boolean getdata(string com) //hàm thực thi dữ liệu có tham số com
        {
            open();
            Boolean check = false;
            try
            {
                SqlCommand sqlc = new SqlCommand(com, con);
                sqlc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception)
            {
                check = false;
            }
            close();
            return check;
        }
        public DataTable setdata(string com) //hàm đọc dữ liệu đỗ dữ liệu vào lưới sử dụng sqldatadapter 
        {
            open();
            DataTable da = new DataTable();
            try
            {
                SqlCommand sqlc = new SqlCommand(com, con);
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlc);
                sqlda.Fill(da);
            }
            catch (Exception)
            {
                da = null;
            }
            close();
            return da;
        }
    }

}

