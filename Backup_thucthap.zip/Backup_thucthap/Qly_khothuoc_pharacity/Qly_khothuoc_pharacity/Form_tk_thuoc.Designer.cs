﻿
namespace Qly_khothuoc_pharacity
{
    partial class Form_tk_thuoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvthuoc = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ranhacc = new System.Windows.Forms.RadioButton();
            this.raten = new System.Windows.Forms.RadioButton();
            this.bt_thoat = new System.Windows.Forms.Button();
            this.txttimkiem = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvthuoc)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvthuoc
            // 
            this.dgvthuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvthuoc.Location = new System.Drawing.Point(39, 180);
            this.dgvthuoc.Margin = new System.Windows.Forms.Padding(4);
            this.dgvthuoc.Name = "dgvthuoc";
            this.dgvthuoc.RowHeadersWidth = 51;
            this.dgvthuoc.Size = new System.Drawing.Size(676, 432);
            this.dgvthuoc.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(362, 115);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 29);
            this.label1.TabIndex = 49;
            this.label1.Text = "TÌM KIẾM THUỐC\r\n";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ranhacc);
            this.groupBox1.Controls.Add(this.raten);
            this.groupBox1.Controls.Add(this.bt_thoat);
            this.groupBox1.Controls.Add(this.txttimkiem);
            this.groupBox1.Location = new System.Drawing.Point(789, 246);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(335, 264);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin tìm kiếm";
            // 
            // ranhacc
            // 
            this.ranhacc.AutoSize = true;
            this.ranhacc.Location = new System.Drawing.Point(191, 58);
            this.ranhacc.Name = "ranhacc";
            this.ranhacc.Size = new System.Drawing.Size(117, 21);
            this.ranhacc.TabIndex = 41;
            this.ranhacc.TabStop = true;
            this.ranhacc.Text = "Nhà cung cấp";
            this.ranhacc.UseVisualStyleBackColor = true;
            // 
            // raten
            // 
            this.raten.AutoSize = true;
            this.raten.Checked = true;
            this.raten.Location = new System.Drawing.Point(36, 58);
            this.raten.Name = "raten";
            this.raten.Size = new System.Drawing.Size(93, 21);
            this.raten.TabIndex = 40;
            this.raten.TabStop = true;
            this.raten.Text = "Tên thuốc";
            this.raten.UseVisualStyleBackColor = true;
            // 
            // bt_thoat
            // 
            this.bt_thoat.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_thoat.Location = new System.Drawing.Point(121, 192);
            this.bt_thoat.Margin = new System.Windows.Forms.Padding(4);
            this.bt_thoat.Name = "bt_thoat";
            this.bt_thoat.Size = new System.Drawing.Size(100, 32);
            this.bt_thoat.TabIndex = 39;
            this.bt_thoat.Text = "Thoát";
            this.bt_thoat.UseVisualStyleBackColor = false;
            this.bt_thoat.Click += new System.EventHandler(this.bt_thoat_Click);
            // 
            // txttimkiem
            // 
            this.txttimkiem.Location = new System.Drawing.Point(36, 125);
            this.txttimkiem.Margin = new System.Windows.Forms.Padding(4);
            this.txttimkiem.Name = "txttimkiem";
            this.txttimkiem.Size = new System.Drawing.Size(265, 22);
            this.txttimkiem.TabIndex = 37;
            this.txttimkiem.TextChanged += new System.EventHandler(this.txttimkiem_TextChanged);
            // 
            // Form_tk_thuoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 767);
            this.Controls.Add(this.dgvthuoc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_tk_thuoc";
            this.Text = "Form_tk_thuoc";
            this.Load += new System.EventHandler(this.Form_tk_thuoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvthuoc)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvthuoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton ranhacc;
        private System.Windows.Forms.RadioButton raten;
        private System.Windows.Forms.Button bt_thoat;
        private System.Windows.Forms.TextBox txttimkiem;
    }
}