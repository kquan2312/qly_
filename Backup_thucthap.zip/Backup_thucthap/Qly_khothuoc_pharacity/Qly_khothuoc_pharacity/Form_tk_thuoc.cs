﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class Form_tk_thuoc : Form
    {
        ketnoi con = new ketnoi();
        public Form_tk_thuoc()
        {
            InitializeComponent();
        }

        private void Form_tk_thuoc_Load(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from thuoc");
            dgvthuoc.DataSource = dt;
        }

        private void txttimkiem_TextChanged(object sender, EventArgs e)
        {
            if (raten.Checked == true)
            {
                DataTable dt1 = con.setdata("select * from thuoc where tenthuoc like N'%" + txttimkiem.Text + "%'");

                dgvthuoc.DataSource = dt1;
            }
            else if (ranhacc.Checked == true)
            {
                DataTable dt2 = con.setdata("select * from thuoc where nhacc like N'%" + txttimkiem.Text + "%'");

                dgvthuoc.DataSource = dt2;
            }
        }

        private void bt_thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormQlyThuoc f = new FormQlyThuoc();
            f.ShowDialog();
        }
    }
}
