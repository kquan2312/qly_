﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class FormDangnhap : Form
    {
        ketnoi con = new ketnoi();
        public FormDangnhap()
        {
            InitializeComponent();
        }

        private void btdangnhap_Click(object sender, EventArgs e)
        {

            if (txtTK.Text == "")
            {
                MessageBox.Show("Bạn phải nhập Username vào!", "Đăng nhập");
                txtTK.Focus();
            }
            else
                if (txtMK.Text == "")
            {
                MessageBox.Show("Bạn phải nhập Password vào!", "Đăng nhập");
                txtMK.Focus();
            }

            else
            {
                try
                {

                    DataTable dt = con.setdata("select * from dangnhap where username = '" + txtTK.Text + "' and password ='" + txtMK.Text + "' ");
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK);
                        this.Hide();
                        FrmMain f = new FrmMain(dt.Rows[0][0].ToString(), dt.Rows[0][1].ToString(), dt.Rows[0][2].ToString(), dt.Rows[0][3].ToString(), dt.Rows[0][4].ToString(), dt.Rows[0][5].ToString());
                       // FrmMain f = new FrmMain();
                        f.ShowDialog();

                    }
                    else
                    {
                        MessageBox.Show("Sai thông tin tài khoản!", "Thông báo");
                        txtTK.Text = "";
                        txtMK.Text = "";
                        txtTK.Focus();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        private void cbhien_CheckedChanged(object sender, EventArgs e)
        {
            if (cbhien.Checked == true)
            {
                txtMK.UseSystemPasswordChar = false;
            }
            else
                txtMK.UseSystemPasswordChar = true;
        }

        private void btnhaplai_Click(object sender, EventArgs e)
        {
            txtMK.Clear();
            txtTK.Clear();
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát chứ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                this.Show();
            }
            else
            {
                this.Close();
            }
        }

        private void txtTK_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                txtMK.Focus();
            }
        }

        private void txtMK_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMK_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btdangnhap.Focus();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
