﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class Form_QLTK : Form
    {
        ketnoi con = new ketnoi();
        public Form_QLTK()
        {

            InitializeComponent();
        }

        private void btthem_Click(object sender, EventArgs e)
        {
            string mod = "user";
            string state = "0";

            if (txtTK.Text == "")
            {
                txtMK.Focus();
                MessageBox.Show("Chưa nhập Tên tài khoản!");
            }
            else if (txtMK.Text == "")
            {
                MessageBox.Show("Chưa nhập Mật khẩu!");
                txtMK.Focus();
            }
            else if (txtten.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên!");
                txtMK.Focus();
            }
            else if (txtemail.Text == "")
            {
                MessageBox.Show("Chưa nhập Email!");
                txtMK.Focus();
            }


            else if (con.getdata("INSERT INTO dangnhap VALUES (N'" + txtTK.Text + "',N'" + txtMK.Text + "',N'" + txtten.Text + "',N'" + txtemail.Text +
                "',N'" + mod + "',N'" + state + "')") == true)
            {

                MessageBox.Show("Thêm thành công");
                Form_QLTK_Load(sender, e);
            }
            else 
                MessageBox.Show("Lỗi Không thể thêm tài khoản");
        }

        private void Form_QLTK_Load(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select username, password, fullname, email, mod from dangnhap");
            if (dt != null)
            {
                dgvtk.DataSource = dt;
            }
        }

        private void btsua_Click(object sender, EventArgs e)
        {
            if (txtTK.Text == "")
            {
                txtMK.Focus();
                MessageBox.Show("Chưa nhập Tên tài khoản!");
            }
            else if (txtMK.Text == "")
            {
                MessageBox.Show("Chưa nhập Mật khẩu!");
                txtMK.Focus();
            }
            else if (txtten.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên!");
                txtMK.Focus();
            }
            else if (txtemail.Text == "")
            {
                MessageBox.Show("Chưa nhập Email!");
                txtMK.Focus();
            }
            else if (con.getdata("update  dangnhap set password=N'" + txtMK.Text + "', fullname = N'" + txtten.Text + "', email = N'" + txtemail.Text +
                "' WHERE username=N'" + txtTK.Text + "'") == true)
            {

                MessageBox.Show("Cập nhật dữ liệu thành công");
                Form_QLTK_Load(sender, e);

            }
            else MessageBox.Show("Không thể cập nhật dữ liệu");
        }

        private void btxoa_Click(object sender, EventArgs e)
        {
            if (txtTK.Text == "")
            {
                txtMK.Focus();
                MessageBox.Show("Chưa nhập Tên tài khoản!");
            }
            else
            {
                DialogResult chon = MessageBox.Show("Bạn có muốn xóa Tài khoản: " + txtTK.Text + "", "Thông báo", MessageBoxButtons.YesNo);
                if (chon == DialogResult.Yes)
                {
                    try
                    {

                        con.getdata("delete FROM dangnhap where username='" + txtTK.Text + "'");
                        MessageBox.Show("Xóa thành Công", "Thông báo");
                        Form_QLTK_Load(sender, e);

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Không thể xóa tài khoản", "Thông báo");
                        throw;
                    }

                }
                else Form_QLTK_Load(sender, e);
            }
        }

        private void btmoi_Click(object sender, EventArgs e)
        {
            txtTK.Text = "";
            txtMK.Text = "";
            txtten.Text = "";
            txtemail.Text = "";
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dgvtk_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable dt = con.setdata("select username, password, fullname, email from dangnhap");
            if (dt != null)
            {
                txtTK.Text = dgvtk.CurrentRow.Cells[0].Value.ToString();
                txtMK.Text = dgvtk.CurrentRow.Cells[1].Value.ToString();
                txtten.Text = dgvtk.CurrentRow.Cells[2].Value.ToString();
                txtemail.Text = dgvtk.CurrentRow.Cells[3].Value.ToString();
            }
        }
    }
}
