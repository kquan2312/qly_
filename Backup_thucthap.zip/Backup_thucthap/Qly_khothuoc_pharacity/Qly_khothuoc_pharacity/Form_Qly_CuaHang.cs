﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class Form_Qly_CuaHang : Form
    {
        ketnoi con = new ketnoi();
        public Form_Qly_CuaHang()
        {
            InitializeComponent();
        }

        private void Form_Qly_CuaHang_Load(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from cuahang");

            if (dt != null)
            {
                dgvcuahang.DataSource = dt;
            }
        }

        private void dgvcuahang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtmacuahang.Text = dgvcuahang.CurrentRow.Cells[0].Value.ToString();
            txttencuahang.Text = dgvcuahang.CurrentRow.Cells[1].Value.ToString();
            txtdiachi.Text = dgvcuahang.CurrentRow.Cells[2].Value.ToString();
            txtdt.Text = dgvcuahang.CurrentRow.Cells[3].Value.ToString();
            txtemail.Text = dgvcuahang.CurrentRow.Cells[4].Value.ToString();
        }

        private void bt_them_Click(object sender, EventArgs e)
        {
            if (txtmacuahang.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã cửa hàng ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmacuahang.Focus();
            }
            else if (txttencuahang.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên!");
                txttencuahang.Focus();
            }
            else if (txtdiachi.Text == "")
            {
                MessageBox.Show("Chưa nhập Địa chỉ!");
                txtdiachi.Focus();
            }
            else if (txtdt.Text == "")
            {
                MessageBox.Show("Chưa nhập Số điện thoại!");
                txtdt.Focus();
            }
            else if (txtemail.Text == "")
            {
                MessageBox.Show("Chưa nhập Email!");
                txtemail.Focus();
            }

            else
            {
                if (con.getdata("insert into cuahang values (N'" + txtmacuahang.Text + "',N'" + txttencuahang.Text + "',N'" + txtdiachi.Text +
                        "',N'" + txtdt.Text + "',N'" + txtemail.Text + "')") == true)
                {

                    MessageBox.Show("Đã thêm cửa hàng thành công ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Form_Qly_CuaHang_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("Thêm cửa hàng thất bại ", "Đã có mã tồn tại", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

            }
        }

        private void bt_sua_Click(object sender, EventArgs e)
        {
            if (txtmacuahang.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã cửa hàng ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmacuahang.Focus();
            }
            else if (txttencuahang.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên!");
                txttencuahang.Focus();
            }
            else if (txtdiachi.Text == "")
            {
                MessageBox.Show("Chưa nhập Địa chỉ!");
                txtdiachi.Focus();
            }
            else if (txtdt.Text == "")
            {
                MessageBox.Show("Chưa nhập Số điện thoại!");
                txtdt.Focus();
            }
            else if (txtemail.Text == "")
            {
                MessageBox.Show("Chưa nhập Email!");
                txtemail.Focus();
            }

            else
            {
                if (con.getdata("update cuahang set macuahang = '" + txtmacuahang.Text + "', tencuahang=N'" + txttencuahang.Text + "', diachi=N'" + txtdiachi.Text +
                "',email=N'" + txtemail.Text + "', dienthoai=N'" + txtdt.Text + "' where macuahang = '" + txtmacuahang.Text + "'") == true)
                {

                    MessageBox.Show("Cập nhật dữ liệu thành công");
                    Form_Qly_CuaHang_Load(sender, e);
                }
                else MessageBox.Show("Không thể sửa dữ liệu");
            }
        }

       

        private void bt_xoa_Click_1(object sender, EventArgs e)
        {
           
        }

        private void bt_lai_Click(object sender, EventArgs e)
        {
            txtmacuahang.Text = "";
            txttencuahang.Text = "";
            txtdiachi.Text = "";
            txtemail.Text = "";
            txtdt.Text = "";
        }

        private void sapxep_Click(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from cuahang order by tencuahang asc");
            if (dt != null)
            {
                dgvcuahang.DataSource = dt;
            }
        }

        private void bt_thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void bt_TK_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_tk_cuahang frm = new Form_tk_cuahang();
            frm.ShowDialog();
        }

        private void bt_xoa_Click(object sender, EventArgs e)
        {
            if (txtmacuahang.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã cửa hàng ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmacuahang.Focus();
            }
            else
            {
                DialogResult chon = MessageBox.Show("Bạn có muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                if (chon == DialogResult.Yes)
                {
                    if (con.getdata("delete FROM cuahang where macuahang = N'" + txtmacuahang.Text + "'") == true)
                    {

                        MessageBox.Show("Đã xóa thành công");
                        Form_Qly_CuaHang_Load(sender, e);

                    }
                    else MessageBox.Show("Không thể cập nhật dữ liệu");
                }
                else Form_Qly_CuaHang_Load(sender, e);
            }
        }
    }
}
