﻿
namespace Qly_khothuoc_pharacity
{
    partial class FormDoiMK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btthoat = new System.Windows.Forms.Button();
            this.txtMKcu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btlai = new System.Windows.Forms.Button();
            this.btdoi = new System.Windows.Forms.Button();
            this.txtLai = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbhienan = new System.Windows.Forms.CheckBox();
            this.txtMKmoi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_tk = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btthoat
            // 
            this.btthoat.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btthoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btthoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btthoat.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btthoat.Location = new System.Drawing.Point(505, 366);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(78, 35);
            this.btthoat.TabIndex = 122;
            this.btthoat.Tag = "4";
            this.btthoat.Text = "Thoát";
            this.btthoat.UseVisualStyleBackColor = false;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // txtMKcu
            // 
            this.txtMKcu.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtMKcu.Location = new System.Drawing.Point(337, 157);
            this.txtMKcu.Name = "txtMKcu";
            this.txtMKcu.Size = new System.Drawing.Size(246, 22);
            this.txtMKcu.TabIndex = 118;
            this.txtMKcu.Tag = "0";
            this.txtMKcu.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(202, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 130;
            this.label1.Text = "Mật khẩu cũ";
            // 
            // btlai
            // 
            this.btlai.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btlai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btlai.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btlai.Location = new System.Drawing.Point(423, 366);
            this.btlai.Name = "btlai";
            this.btlai.Size = new System.Drawing.Size(75, 35);
            this.btlai.TabIndex = 123;
            this.btlai.Tag = "5";
            this.btlai.Text = "Nhập lại";
            this.btlai.UseVisualStyleBackColor = false;
            this.btlai.Click += new System.EventHandler(this.btlai_Click);
            // 
            // btdoi
            // 
            this.btdoi.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btdoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btdoi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btdoi.Location = new System.Drawing.Point(337, 366);
            this.btdoi.Name = "btdoi";
            this.btdoi.Size = new System.Drawing.Size(75, 35);
            this.btdoi.TabIndex = 124;
            this.btdoi.Tag = "6";
            this.btdoi.Text = "Đổi";
            this.btdoi.UseVisualStyleBackColor = false;
            this.btdoi.Click += new System.EventHandler(this.btdoi_Click);
            // 
            // txtLai
            // 
            this.txtLai.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtLai.Location = new System.Drawing.Point(337, 269);
            this.txtLai.Name = "txtLai";
            this.txtLai.Size = new System.Drawing.Size(246, 22);
            this.txtLai.TabIndex = 120;
            this.txtLai.Tag = "2";
            this.txtLai.UseSystemPasswordChar = true;
            this.txtLai.TextChanged += new System.EventHandler(this.txtLai_TextChanged);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(202, 255);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 40);
            this.label8.TabIndex = 129;
            this.label8.Text = "Nhập lại \r\nmật khẩu\r\n";
            // 
            // cbhienan
            // 
            this.cbhienan.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbhienan.AutoSize = true;
            this.cbhienan.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cbhienan.Location = new System.Drawing.Point(519, 297);
            this.cbhienan.Name = "cbhienan";
            this.cbhienan.Size = new System.Drawing.Size(79, 21);
            this.cbhienan.TabIndex = 121;
            this.cbhienan.Tag = "3";
            this.cbhienan.Text = "Hiển/ẩn";
            this.cbhienan.UseVisualStyleBackColor = true;
            this.cbhienan.CheckedChanged += new System.EventHandler(this.cbhienan_CheckedChanged);
            // 
            // txtMKmoi
            // 
            this.txtMKmoi.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtMKmoi.Location = new System.Drawing.Point(337, 209);
            this.txtMKmoi.Name = "txtMKmoi";
            this.txtMKmoi.Size = new System.Drawing.Size(246, 22);
            this.txtMKmoi.TabIndex = 119;
            this.txtMKmoi.Tag = "1";
            this.txtMKmoi.UseSystemPasswordChar = true;
            this.txtMKmoi.TextChanged += new System.EventHandler(this.txtMKmoi_TextChanged);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(202, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 20);
            this.label5.TabIndex = 128;
            this.label5.Text = "Mật khẩu mới";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(202, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 20);
            this.label6.TabIndex = 127;
            this.label6.Text = "Tài khoản";
            // 
            // lb
            // 
            this.lb.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lb.AutoSize = true;
            this.lb.ForeColor = System.Drawing.Color.Red;
            this.lb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lb.Location = new System.Drawing.Point(358, 298);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(146, 34);
            this.lb.TabIndex = 126;
            this.lb.Text = "Mật khẩu không trùng\r\n\r\n";
            this.lb.Visible = false;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(295, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 32);
            this.label4.TabIndex = 125;
            this.label4.Text = "ĐỔI MẬT KHẨU\r\n";
            // 
            // cb_tk
            // 
            this.cb_tk.FormattingEnabled = true;
            this.cb_tk.Location = new System.Drawing.Point(337, 108);
            this.cb_tk.Name = "cb_tk";
            this.cb_tk.Size = new System.Drawing.Size(246, 24);
            this.cb_tk.TabIndex = 131;
            // 
            // FormDoiMK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cb_tk);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.txtMKcu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btlai);
            this.Controls.Add(this.btdoi);
            this.Controls.Add(this.txtLai);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbhienan);
            this.Controls.Add(this.txtMKmoi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lb);
            this.Controls.Add(this.label4);
            this.Name = "FormDoiMK";
            this.Text = "FormDoiMK";
            this.Load += new System.EventHandler(this.FormDoiMK_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.TextBox txtMKcu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btlai;
        private System.Windows.Forms.Button btdoi;
        private System.Windows.Forms.TextBox txtLai;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox cbhienan;
        private System.Windows.Forms.TextBox txtMKmoi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_tk;
    }
}