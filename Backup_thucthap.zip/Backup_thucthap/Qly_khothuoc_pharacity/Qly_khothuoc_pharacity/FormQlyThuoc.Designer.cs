﻿
namespace Qly_khothuoc_pharacity
{
    partial class FormQlyThuoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtsoluong = new System.Windows.Forms.TextBox();
            this.sapxep = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtnhacc = new System.Windows.Forms.TextBox();
            this.txtdongia = new System.Windows.Forms.TextBox();
            this.bt_lai = new System.Windows.Forms.Button();
            this.bt_TK = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.bt_thoat = new System.Windows.Forms.Button();
            this.bt_xoa = new System.Windows.Forms.Button();
            this.bt_sua = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmathuoc = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_them = new System.Windows.Forms.Button();
            this.dgvthuoc = new System.Windows.Forms.DataGridView();
            this.txtthanhtien = new System.Windows.Forms.TextBox();
            this.txttenthuoc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
           // this.qlquaythuocDataSet4 = new Qly_khothuoc_pharacity.qlquaythuocDataSet4();
            this.thuocBindingSource = new System.Windows.Forms.BindingSource(this.components);
          //  this.thuocTableAdapter = new Qly_khothuoc_pharacity.qlquaythuocDataSet4TableAdapters.thuocTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvthuoc)).BeginInit();
        //    ((System.ComponentModel.ISupportInitialize)(this.qlquaythuocDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuocBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtsoluong
            // 
            this.txtsoluong.Location = new System.Drawing.Point(924, 291);
            this.txtsoluong.Name = "txtsoluong";
            this.txtsoluong.Size = new System.Drawing.Size(239, 22);
            this.txtsoluong.TabIndex = 234;
            // 
            // sapxep
            // 
            this.sapxep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sapxep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.sapxep.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sapxep.Location = new System.Drawing.Point(699, 698);
            this.sapxep.Name = "sapxep";
            this.sapxep.Size = new System.Drawing.Size(131, 40);
            this.sapxep.TabIndex = 244;
            this.sapxep.Text = "Sắp xếp";
            this.sapxep.UseVisualStyleBackColor = false;
            this.sapxep.Click += new System.EventHandler(this.sapxep_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(800, 449);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 253;
            this.label8.Text = "Nhà cung cấp";
            // 
            // txtnhacc
            // 
            this.txtnhacc.Location = new System.Drawing.Point(924, 445);
            this.txtnhacc.Multiline = true;
            this.txtnhacc.Name = "txtnhacc";
            this.txtnhacc.Size = new System.Drawing.Size(243, 74);
            this.txtnhacc.TabIndex = 237;
            // 
            // txtdongia
            // 
            this.txtdongia.Location = new System.Drawing.Point(924, 341);
            this.txtdongia.Name = "txtdongia";
            this.txtdongia.Size = new System.Drawing.Size(243, 22);
            this.txtdongia.TabIndex = 235;
            this.txtdongia.TextChanged += new System.EventHandler(this.txtdongia_TextChanged);
            // 
            // bt_lai
            // 
            this.bt_lai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_lai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_lai.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_lai.Location = new System.Drawing.Point(1036, 616);
            this.bt_lai.Name = "bt_lai";
            this.bt_lai.Size = new System.Drawing.Size(131, 40);
            this.bt_lai.TabIndex = 242;
            this.bt_lai.Text = "Nhập lại";
            this.bt_lai.UseVisualStyleBackColor = false;
            this.bt_lai.Click += new System.EventHandler(this.bt_lai_Click);
            // 
            // bt_TK
            // 
            this.bt_TK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_TK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_TK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_TK.Location = new System.Drawing.Point(528, 698);
            this.bt_TK.Name = "bt_TK";
            this.bt_TK.Size = new System.Drawing.Size(131, 40);
            this.bt_TK.TabIndex = 243;
            this.bt_TK.Text = "Tìm kiếm";
            this.bt_TK.UseVisualStyleBackColor = false;
            this.bt_TK.Click += new System.EventHandler(this.bt_TK_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(800, 400);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 20);
            this.label7.TabIndex = 252;
            this.label7.Text = "Thành tiền";
            // 
            // bt_thoat
            // 
            this.bt_thoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_thoat.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_thoat.Location = new System.Drawing.Point(865, 698);
            this.bt_thoat.Name = "bt_thoat";
            this.bt_thoat.Size = new System.Drawing.Size(131, 40);
            this.bt_thoat.TabIndex = 245;
            this.bt_thoat.Text = "Thoát";
            this.bt_thoat.UseVisualStyleBackColor = false;
            this.bt_thoat.Click += new System.EventHandler(this.bt_thoat_Click);
            // 
            // bt_xoa
            // 
            this.bt_xoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_xoa.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_xoa.Location = new System.Drawing.Point(865, 616);
            this.bt_xoa.Name = "bt_xoa";
            this.bt_xoa.Size = new System.Drawing.Size(131, 40);
            this.bt_xoa.TabIndex = 241;
            this.bt_xoa.Text = "Xóa";
            this.bt_xoa.UseVisualStyleBackColor = false;
            this.bt_xoa.Click += new System.EventHandler(this.bt_xoa_Click);
            // 
            // bt_sua
            // 
            this.bt_sua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_sua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_sua.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_sua.Location = new System.Drawing.Point(699, 616);
            this.bt_sua.Name = "bt_sua";
            this.bt_sua.Size = new System.Drawing.Size(131, 40);
            this.bt_sua.TabIndex = 240;
            this.bt_sua.Text = "Sửa";
            this.bt_sua.UseVisualStyleBackColor = false;
            this.bt_sua.Click += new System.EventHandler(this.bt_sua_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(800, 345);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 251;
            this.label5.Text = "Đơn giá";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(800, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 250;
            this.label4.Text = "Số lượng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(800, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 20);
            this.label2.TabIndex = 249;
            this.label2.Text = "Tên";
            // 
            // txtmathuoc
            // 
            this.txtmathuoc.Location = new System.Drawing.Point(924, 177);
            this.txtmathuoc.Name = "txtmathuoc";
            this.txtmathuoc.Size = new System.Drawing.Size(243, 22);
            this.txtmathuoc.TabIndex = 232;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(800, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 20);
            this.label6.TabIndex = 248;
            this.label6.Text = "Mã thuốc";
            // 
            // bt_them
            // 
            this.bt_them.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_them.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_them.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_them.Location = new System.Drawing.Point(528, 616);
            this.bt_them.Name = "bt_them";
            this.bt_them.Size = new System.Drawing.Size(131, 40);
            this.bt_them.TabIndex = 239;
            this.bt_them.Text = "Thêm";
            this.bt_them.UseVisualStyleBackColor = false;
            this.bt_them.Click += new System.EventHandler(this.bt_them_Click);
            // 
            // dgvthuoc
            // 
            this.dgvthuoc.AllowUserToAddRows = false;
            this.dgvthuoc.AllowUserToDeleteRows = false;
            this.dgvthuoc.AllowUserToResizeColumns = false;
            this.dgvthuoc.AllowUserToResizeRows = false;
            this.dgvthuoc.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvthuoc.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dgvthuoc.ColumnHeadersHeight = 29;
            this.dgvthuoc.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvthuoc.Location = new System.Drawing.Point(51, 177);
            this.dgvthuoc.Name = "dgvthuoc";
            this.dgvthuoc.ReadOnly = true;
            this.dgvthuoc.RowHeadersWidth = 51;
            this.dgvthuoc.RowTemplate.Height = 24;
            this.dgvthuoc.ShowCellToolTips = false;
            this.dgvthuoc.Size = new System.Drawing.Size(734, 388);
            this.dgvthuoc.TabIndex = 247;
            this.dgvthuoc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvthuoc_CellContentClick);
            // 
            // txtthanhtien
            // 
            this.txtthanhtien.Location = new System.Drawing.Point(924, 396);
            this.txtthanhtien.Name = "txtthanhtien";
            this.txtthanhtien.Size = new System.Drawing.Size(243, 22);
            this.txtthanhtien.TabIndex = 236;
            this.txtthanhtien.TextChanged += new System.EventHandler(this.txtthanhtien_TextChanged);
            // 
            // txttenthuoc
            // 
            this.txttenthuoc.Location = new System.Drawing.Point(924, 230);
            this.txttenthuoc.Name = "txttenthuoc";
            this.txttenthuoc.Size = new System.Drawing.Size(243, 22);
            this.txttenthuoc.TabIndex = 233;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(261, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(483, 32);
            this.label1.TabIndex = 246;
            this.label1.Text = "CHƯƠNG TRÌNH QUẢN LÝ THUỐC\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(1036, 698);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 64);
            this.button1.TabIndex = 259;
            this.button1.Text = "Tạo Hóa đơn xuất";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // qlquaythuocDataSet4
            // 
            //this.qlquaythuocDataSet4.DataSetName = "qlquaythuocDataSet4";
           // this.qlquaythuocDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // thuocBindingSource
            // 
            this.thuocBindingSource.DataMember = "thuoc";
          //  this.thuocBindingSource.DataSource = this.qlquaythuocDataSet4;
            // 
            // thuocTableAdapter
            // 
           // this.thuocTableAdapter.ClearBeforeFill = true;
            // 
            // FormQlyThuoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 853);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtsoluong);
            this.Controls.Add(this.sapxep);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtnhacc);
            this.Controls.Add(this.txtdongia);
            this.Controls.Add(this.bt_lai);
            this.Controls.Add(this.bt_TK);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bt_thoat);
            this.Controls.Add(this.bt_xoa);
            this.Controls.Add(this.bt_sua);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtmathuoc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bt_them);
            this.Controls.Add(this.dgvthuoc);
            this.Controls.Add(this.txtthanhtien);
            this.Controls.Add(this.txttenthuoc);
            this.Controls.Add(this.label1);
            this.Name = "FormQlyThuoc";
            this.Text = "FormQlyThuoc";
            this.Load += new System.EventHandler(this.FormQlyThuoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvthuoc)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.qlquaythuocDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thuocBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtsoluong;
        private System.Windows.Forms.Button sapxep;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtnhacc;
        private System.Windows.Forms.TextBox txtdongia;
        private System.Windows.Forms.Button bt_lai;
        private System.Windows.Forms.Button bt_TK;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button bt_thoat;
        private System.Windows.Forms.Button bt_xoa;
        private System.Windows.Forms.Button bt_sua;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtmathuoc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_them;
        private System.Windows.Forms.DataGridView dgvthuoc;
        private System.Windows.Forms.TextBox txtthanhtien;
        private System.Windows.Forms.TextBox txttenthuoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
       // private qlquaythuocDataSet4 qlquaythuocDataSet4;
        private System.Windows.Forms.BindingSource thuocBindingSource;
        //private qlquaythuocDataSet4TableAdapters.thuocTableAdapter thuocTableAdapter;
    }
}