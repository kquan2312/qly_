﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    
    public partial class FormQlyThuoc : Form
    {
        ketnoi con = new ketnoi();
        public FormQlyThuoc()
        {
            InitializeComponent();
        }

        private void FormQlyThuoc_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qlquaythuocDataSet4.thuoc' table. You can move, or remove it, as needed.
            // this.thuocTableAdapter.Fill(this.qlquaythuocDataSet4.thuoc);
            //DataTable dt1 = con.setdata("select * from cuahang");
            //cbbmacuahang.DataSource = dt1;
            //cbbmacuahang.DisplayMember = "macuahang";
            //cbbmacuahang.ValueMember = "macuahang";
            //dgvthuoc.Columns[0].HeaderText = "Mã thuốc";
            //dgvthuoc.Columns[1].HeaderText = "Tên thuốc";
            //dgvthuoc.Columns[2].HeaderText = "Số lượng";
            //dgvthuoc.Columns[3].HeaderText = "Đơn giá";
            //dgvthuoc.Columns[4].HeaderText = "Thành tiền";
            //dgvthuoc.Columns[5].HeaderText = "Nhà cung cấp";

            DataTable dt2 = con.setdata("select * from thuoc");
            txtthanhtien.ReadOnly = true;
            if (dt2 != null && dt2.Rows.Count > 0)
            {
                dgvthuoc.DataSource = dt2;
            }

            else
            {
                MessageBox.Show("Dòng được chọn không hợp lệ.", "Thông báo");
            }
        }

        private void dgvthuoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvthuoc.Rows.Count > 0 && dgvthuoc.CurrentRow != null)
            //if (dgvthuoc.CurrentRow != null && dgvthuoc.CurrentRow.Index >= 0 && dgvthuoc.CurrentRow.Index < dgvthuoc.Rows.Count)
            {
                txtmathuoc.Text = dgvthuoc.CurrentRow.Cells[0].Value.ToString();
                txttenthuoc.Text = dgvthuoc.CurrentRow.Cells[1].Value.ToString();
                txtsoluong.Text = dgvthuoc.CurrentRow.Cells[2].Value.ToString();
                txtdongia.Text = dgvthuoc.CurrentRow.Cells[3].Value.ToString();
                txtthanhtien.Text = dgvthuoc.CurrentRow.Cells[4].Value.ToString();
                txtnhacc.Text = dgvthuoc.CurrentRow.Cells[5].Value.ToString();
                //cbbmacuahang.Text = dgvthuoc.CurrentRow.Cells[6].Value.ToString();
            }
        }

        private void bt_thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void bt_them_Click(object sender, EventArgs e)
        {
            if (txtmathuoc.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã thuốc ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmathuoc.Focus();
            }
            else if (txttenthuoc.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên thuốc");
                txttenthuoc.Focus();
            }
            else if (txtdongia.Text == "")
            {
                MessageBox.Show("Chưa nhập đơn giá");
                txtdongia.Focus();
            }
            else if (txtthanhtien.Text == "")
            {
                MessageBox.Show("Chưa nhập");
                txtthanhtien.Focus();
            }
            else if (txtnhacc.Text == "")
            {
                MessageBox.Show("Chưa nhập nhà cung cấp");
                txtnhacc.Focus();
            }
            
            else
            {
                if (con.getdata("insert into thuoc values (N'" + txtmathuoc.Text + "',N'" + txttenthuoc.Text + "',N'" + txtsoluong.Text + "'," +
                    "N'" + txtdongia.Text + "',N'" + txtthanhtien.Text + "',N'" + txtnhacc.Text + "')") == true)
                {
                    MessageBox.Show("Đã thêm thuốc thành công ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FormQlyThuoc_Load(sender, e);
                }
                else MessageBox.Show("Lỗi trùng Tên");
            }
        }

        private void bt_sua_Click(object sender, EventArgs e)
        {
            if (txtmathuoc.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã thuốc ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmathuoc.Focus();
            }
            else if (txttenthuoc.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên thuốc");
                txttenthuoc.Focus();
            }
            else if (txtdongia.Text == "")
            {
                MessageBox.Show("Chưa nhập Quê quán");
                txtdongia.Focus();
            }
            else if (txtthanhtien.Text == "")
            {
                MessageBox.Show("Chưa nhập Năm");
                txtthanhtien.Focus();
            }
            else if (txtnhacc.Text == "")
            {
                MessageBox.Show("Chưa nhập Lương");
                txtnhacc.Focus();
            }
            //else if (cbbmacuahang.Text == "")
            //{
            //    MessageBox.Show("Chưa nhập Mã cửa hàng");
            //    cbbmacuahang.Focus();
            //}
            else
            {
                if (con.getdata("update thuoc set tenthuoc=N'" + txttenthuoc.Text + "', soluong=N'" + txtsoluong.Text + "',dongia=N'" + txtdongia.Text + "', thanhtien=N'"
                    + txtthanhtien.Text + "',nhacc=N'" + txtnhacc.Text + "' where mathuoc = '" + txtmathuoc.Text + "'") == true)
                {

                    MessageBox.Show("Cập nhật dữ liệu thành công");

                    FormQlyThuoc_Load(sender, e);

                }
                else MessageBox.Show("Không thể cập nhật dữ liệu");
            }
        }

        private void bt_xoa_Click(object sender, EventArgs e)
        {
            if (txtmathuoc.Text == "")
            {
                MessageBox.Show("Chưa nhập Mã thuốc ", "Thêm dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmathuoc.Focus();
            }
            else
            {
                DialogResult chon = MessageBox.Show("Bạn có muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                if (chon == DialogResult.Yes)
                {
                    if (con.getdata("delete FROM thuoc where mathuoc = N'" + txtmathuoc.Text + "'") == true)
                    {

                        MessageBox.Show("Xóa dữ liệu thành công");

                        FormQlyThuoc_Load(sender, e);
                    }
                    else MessageBox.Show("Không thể xóa dữ liệu");
                }
                else FormQlyThuoc_Load(sender, e);
            }
        }

        private void bt_lai_Click(object sender, EventArgs e)
        {
            txtmathuoc.Text = "";
            txttenthuoc.Text = "";
            txtdongia.Text = "";
            txtnhacc.Text = "";
            txtthanhtien.Text = "";
        }

        private void bt_TK_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_tk_thuoc f = new Form_tk_thuoc();
            f.ShowDialog();
        }

        private void sapxep_Click(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from thuoc order by dongia desc");

            if (dt != null)
            {
                dgvthuoc.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmHoaDonXuatThuoc f = new FrmHoaDonXuatThuoc();
            f.ShowDialog();
            
        }

        private void txtthanhtien_TextChanged(object sender, EventArgs e)
        {

        }

        public bool kiemtraso(string pvalue)
        {
            foreach (char c in pvalue)
            {
                if ((char.IsDigit(c)) || (char.IsLetter('.')))
                {
                    return true;
                }
            }
            return false;
        }
        private void txtdongia_TextChanged(object sender, EventArgs e)
        {
           
            if (txtsoluong.Text == "")
            {
                MessageBox.Show("Bạn chưa số lượng", "Nhập liệu");
                txtsoluong.Focus();
            }
            else if (!kiemtraso(txtsoluong.Text))
            {
                MessageBox.Show("Bạn phải nhập số vào!", "Thông báo");
                txtsoluong.Clear();
                txtsoluong.Focus();
            }
            else
                if (txtdongia.Text == "")
            {
                MessageBox.Show("Bạn chưa đơn giá", "Nhập liệu");
                txtdongia.Focus();
            }
            else if (!kiemtraso(txtdongia.Text))
            {
                MessageBox.Show("Bạn phải nhập số vào!", "Thông báo");
                txtdongia.Clear();
                txtdongia.Focus();
            }

            else
            {
                double so1, so2, tich;
                so1 = Convert.ToDouble(txtsoluong.Text);
                so2 = Convert.ToDouble(txtdongia.Text);
                tich = so1 * so2;
                txtthanhtien.Text = tich.ToString();
            }
        }
    }
}
