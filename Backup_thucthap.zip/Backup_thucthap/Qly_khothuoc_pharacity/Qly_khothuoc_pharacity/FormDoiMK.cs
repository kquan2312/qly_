﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{

    public partial class FormDoiMK : Form
    {
        ketnoi con = new ketnoi();
        public FormDoiMK()
        {
            InitializeComponent();
        }

        private void btdoi_Click(object sender, EventArgs e)
        {
            string user = cb_tk.Text;
            string pass = txtMKcu.Text;
            string newpass = txtMKmoi.Text;

            if (cb_tk.Text == "")
            {
                MessageBox.Show("Chưa chọn tên tài khoản");
                cb_tk.Focus();

            }
            else if (txtMKcu.Text == "")
            {
                MessageBox.Show("Chưa nhập mật khẩu");
                txtMKmoi.Focus();
            }
            else if (txtMKmoi.Text == "")
            {
                MessageBox.Show("Chưa nhập mật khẩu mới");
                txtMKmoi.Focus();
            }
            else if (txtLai.Text == "")
            {
                MessageBox.Show("Chưa nhập lại mật khẩu");
                txtLai.Focus();
            }


            else if (con.getdata("update dangnhap set password=N'" + newpass + "' where username = '" + user + "' and password ='" + pass + "' ") == true)
            {

                MessageBox.Show("Cập nhật dữ liệu thành công");
            }
            else MessageBox.Show("Không thể cập nhật dữ liệu");
        }

        private void FormDoiMK_Load(object sender, EventArgs e)
        {
            DataTable dt1 = con.setdata("select * from dangnhap");
            cb_tk.DataSource = dt1;
            cb_tk.DisplayMember = "username";
            cb_tk.ValueMember = "username";
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btlai_Click(object sender, EventArgs e)
        {
            cb_tk.Text = "";
            txtMKmoi.Text = "";
            txtLai.Text = "";
            txtMKcu.Text = "";
            cb_tk.Focus();
        }

        private void cbhienan_CheckedChanged(object sender, EventArgs e)
        {
            if (cbhienan.Checked == true)
            {
                txtMKcu.UseSystemPasswordChar = false;
                txtMKmoi.UseSystemPasswordChar = false;
                txtLai.UseSystemPasswordChar = false;
            }
            else
            {
                txtMKcu.UseSystemPasswordChar = true;
                txtMKmoi.UseSystemPasswordChar = true;
                txtLai.UseSystemPasswordChar = true;
            }
                
        }

        private void txtMKmoi_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLai_TextChanged(object sender, EventArgs e)
        {
            if (txtLai.Text != txtMKmoi.Text)
            {
                lb.Visible = true;
            }
            else
                lb.Visible = false;
        }
    }
}
