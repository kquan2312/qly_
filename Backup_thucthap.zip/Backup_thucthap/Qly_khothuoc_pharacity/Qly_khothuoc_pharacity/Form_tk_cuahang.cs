﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qly_khothuoc_pharacity
{
    public partial class Form_tk_cuahang : Form
    {
        ketnoi con = new ketnoi();
        public Form_tk_cuahang()
        {
            InitializeComponent();
        }

        private void Form_tk_cuahang_Load(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from cuahang");
            dgvcuahang.DataSource = dt;
        }

        private void bt_thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txttimkiem_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = con.setdata("select * from cuahang where tencuahang like N'%" + txttimkiem.Text + "%'");

            dgvcuahang.DataSource = dt;
        }
    }
}
