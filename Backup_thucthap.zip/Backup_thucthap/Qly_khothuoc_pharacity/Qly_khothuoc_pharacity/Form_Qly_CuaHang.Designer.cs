﻿
namespace Qly_khothuoc_pharacity
{
    partial class Form_Qly_CuaHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtdiachi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txttencuahang = new System.Windows.Forms.TextBox();
            this.txtmacuahang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtdt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.sapxep = new System.Windows.Forms.Button();
            this.bt_them = new System.Windows.Forms.Button();
            this.bt_thoat = new System.Windows.Forms.Button();
            this.bt_xoa = new System.Windows.Forms.Button();
            this.bt_lai = new System.Windows.Forms.Button();
            this.bt_sua = new System.Windows.Forms.Button();
            this.dgvcuahang = new System.Windows.Forms.DataGridView();
            this.bt_TK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcuahang)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtdiachi);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txttencuahang);
            this.groupBox1.Controls.Add(this.txtmacuahang);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txtdt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(686, 142);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(439, 309);
            this.groupBox1.TabIndex = 197;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin";
            // 
            // txtdiachi
            // 
            this.txtdiachi.Location = new System.Drawing.Point(166, 133);
            this.txtdiachi.Multiline = true;
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(243, 30);
            this.txtdiachi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(17, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 153;
            this.label3.Text = "Địa chỉ";
            // 
            // txttencuahang
            // 
            this.txttencuahang.Location = new System.Drawing.Point(166, 73);
            this.txttencuahang.Multiline = true;
            this.txttencuahang.Name = "txttencuahang";
            this.txttencuahang.Size = new System.Drawing.Size(243, 30);
            this.txttencuahang.TabIndex = 1;
            // 
            // txtmacuahang
            // 
            this.txtmacuahang.Location = new System.Drawing.Point(166, 21);
            this.txtmacuahang.Multiline = true;
            this.txtmacuahang.Name = "txtmacuahang";
            this.txtmacuahang.Size = new System.Drawing.Size(243, 30);
            this.txtmacuahang.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(17, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 20);
            this.label5.TabIndex = 141;
            this.label5.Text = "Điện thoại";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(166, 256);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(243, 30);
            this.txtemail.TabIndex = 4;
            // 
            // txtdt
            // 
            this.txtdt.Location = new System.Drawing.Point(166, 194);
            this.txtdt.Multiline = true;
            this.txtdt.Name = "txtdt";
            this.txtdt.Size = new System.Drawing.Size(243, 30);
            this.txtdt.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(17, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 140;
            this.label4.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(17, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 138;
            this.label2.Text = "Tên cửa hàng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(17, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 20);
            this.label6.TabIndex = 136;
            this.label6.Text = "Mã cửa hàng";
            // 
            // sapxep
            // 
            this.sapxep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sapxep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.sapxep.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sapxep.Location = new System.Drawing.Point(656, 625);
            this.sapxep.Name = "sapxep";
            this.sapxep.Size = new System.Drawing.Size(131, 40);
            this.sapxep.TabIndex = 203;
            this.sapxep.Text = "Sắp xếp";
            this.sapxep.UseVisualStyleBackColor = false;
            this.sapxep.Click += new System.EventHandler(this.sapxep_Click);
            // 
            // bt_them
            // 
            this.bt_them.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_them.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_them.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_them.Location = new System.Drawing.Point(485, 539);
            this.bt_them.Name = "bt_them";
            this.bt_them.Size = new System.Drawing.Size(131, 41);
            this.bt_them.TabIndex = 198;
            this.bt_them.Text = "Thêm";
            this.bt_them.UseVisualStyleBackColor = false;
            this.bt_them.Click += new System.EventHandler(this.bt_them_Click);
            // 
            // bt_thoat
            // 
            this.bt_thoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_thoat.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_thoat.Location = new System.Drawing.Point(822, 624);
            this.bt_thoat.Name = "bt_thoat";
            this.bt_thoat.Size = new System.Drawing.Size(131, 41);
            this.bt_thoat.TabIndex = 204;
            this.bt_thoat.Text = "Thoát";
            this.bt_thoat.UseVisualStyleBackColor = false;
            this.bt_thoat.Click += new System.EventHandler(this.bt_thoat_Click);
            // 
            // bt_xoa
            // 
            this.bt_xoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_xoa.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_xoa.Location = new System.Drawing.Point(822, 539);
            this.bt_xoa.Name = "bt_xoa";
            this.bt_xoa.Size = new System.Drawing.Size(131, 41);
            this.bt_xoa.TabIndex = 200;
            this.bt_xoa.Text = "Xóa";
            this.bt_xoa.UseVisualStyleBackColor = false;
            this.bt_xoa.Click += new System.EventHandler(this.bt_xoa_Click);
            // 
            // bt_lai
            // 
            this.bt_lai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_lai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_lai.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_lai.Location = new System.Drawing.Point(994, 539);
            this.bt_lai.Name = "bt_lai";
            this.bt_lai.Size = new System.Drawing.Size(131, 41);
            this.bt_lai.TabIndex = 201;
            this.bt_lai.Text = "Nhập lại";
            this.bt_lai.UseVisualStyleBackColor = false;
            this.bt_lai.Click += new System.EventHandler(this.bt_lai_Click);
            // 
            // bt_sua
            // 
            this.bt_sua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_sua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_sua.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_sua.Location = new System.Drawing.Point(656, 539);
            this.bt_sua.Name = "bt_sua";
            this.bt_sua.Size = new System.Drawing.Size(131, 41);
            this.bt_sua.TabIndex = 199;
            this.bt_sua.Text = "Sửa";
            this.bt_sua.UseVisualStyleBackColor = false;
            this.bt_sua.Click += new System.EventHandler(this.bt_sua_Click);
            // 
            // dgvcuahang
            // 
            this.dgvcuahang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcuahang.Location = new System.Drawing.Point(72, 123);
            this.dgvcuahang.Name = "dgvcuahang";
            this.dgvcuahang.RowHeadersWidth = 51;
            this.dgvcuahang.RowTemplate.Height = 24;
            this.dgvcuahang.Size = new System.Drawing.Size(608, 373);
            this.dgvcuahang.TabIndex = 206;
            this.dgvcuahang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvcuahang_CellContentClick);
            // 
            // bt_TK
            // 
            this.bt_TK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bt_TK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_TK.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_TK.Location = new System.Drawing.Point(485, 625);
            this.bt_TK.Name = "bt_TK";
            this.bt_TK.Size = new System.Drawing.Size(131, 40);
            this.bt_TK.TabIndex = 202;
            this.bt_TK.Text = "Tìm kiếm";
            this.bt_TK.UseVisualStyleBackColor = false;
            this.bt_TK.Click += new System.EventHandler(this.bt_TK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(265, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(533, 32);
            this.label1.TabIndex = 205;
            this.label1.Text = "CHƯƠNG TRÌNH QUẢN LÝ CỬA HÀNG\r\n";
            // 
            // Form_Qly_CuaHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1174, 780);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.sapxep);
            this.Controls.Add(this.bt_them);
            this.Controls.Add(this.bt_thoat);
            this.Controls.Add(this.bt_xoa);
            this.Controls.Add(this.bt_lai);
            this.Controls.Add(this.bt_sua);
            this.Controls.Add(this.dgvcuahang);
            this.Controls.Add(this.bt_TK);
            this.Controls.Add(this.label1);
            this.Name = "Form_Qly_CuaHang";
            this.Text = "Form_Qly_CuaHang";
            this.Load += new System.EventHandler(this.Form_Qly_CuaHang_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcuahang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtdiachi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttencuahang;
        private System.Windows.Forms.TextBox txtmacuahang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtdt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button sapxep;
        private System.Windows.Forms.Button bt_them;
        private System.Windows.Forms.Button bt_thoat;
        private System.Windows.Forms.Button bt_xoa;
        private System.Windows.Forms.Button bt_lai;
        private System.Windows.Forms.Button bt_sua;
        private System.Windows.Forms.DataGridView dgvcuahang;
        private System.Windows.Forms.Button bt_TK;
        private System.Windows.Forms.Label label1;
    }
}